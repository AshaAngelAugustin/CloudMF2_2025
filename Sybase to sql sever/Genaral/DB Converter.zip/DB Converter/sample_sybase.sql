-- Sample Sybase SQL Script
CREATE TABLE employees (
    emp_id int identity(1,1) PRIMARY KEY,
    emp_name nvarchar(100),
    is_active bit,
    hire_date datetime
);

go

INSERT INTO employees (emp_name, is_active, hire_date)
VALUES ('John Doe', 1, getdate());

go

SELECT emp_id, emp_name, isnull(is_active, 0) as is_active, hire_date
FROM employees;

go
